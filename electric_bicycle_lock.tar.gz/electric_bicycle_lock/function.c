/**
 * @file function.c
 * @brief Implementation of functions used to write on LCD display
 *
 * @date 2021
 * @author Mihailo Grbic (gm170047d@student.etf.bg.ac.rs)
 */

#include <msp430.h>
#include "function.h"


void lcd_pulse_enable()
{
    P8OUT &= ~LCM_PIN_EN;           // Set enable bit to 0
    __delay_cycles(DELAY_20US);     // Keep enable bit for max period
    P8OUT |= LCM_PIN_EN;            // Set enable bit to 1
    __delay_cycles(DELAY_250US);    // Keep enable bit for max period
    P8OUT &= ~LCM_PIN_EN;           // Set enable bit to 0
    __delay_cycles(DELAY_20US);     // Keep enable bit for max period
}

void lcd_send_byte(char data, int isData)
{
    P8OUT &= ~LCM_PIN_MASK;         // Clear all pins

    if(isData == TRUE)
    {
        P8OUT |= LCM_PIN_RS;        // Send data
        __delay_cycles(DELAY_40US); // Wait for address setup time
    }

    P8OUT |= (data & 0xf0);         // Upper nibble

    lcd_pulse_enable();             // Send data/command
    __delay_cycles(DELAY_10US);     // Wait for address hold time

    P8OUT &= ~LCM_DATA_MASK;        // Clear data

    P8OUT |= ((data & 0x0f) << 4);  // Lower nibble

    lcd_pulse_enable();             // Send data/command
    __delay_cycles(DELAY_10US);     // Wait for address hold time

    P8OUT &= ~LCM_PIN_MASK;         // Clear all pins
}

void lcd_initialize()
{
    P8DIR |=  LCM_PIN_MASK;     // Configure P8.2-P8.7 as out
    P8OUT &= ~LCM_PIN_MASK;     // Set P8.2-P8.7 to 0

    /* Initialize by instructions */

    __delay_cycles(DELAY_100MS);    // Wait for Vcc to rise

    P8OUT = 0x30;                  // BF cannot be checked before this instruction
    lcd_pulse_enable();            // Send instruction
    __delay_cycles(DELAY_5MS);     // Wait unitl next commnad

    P8OUT = 0x30;                  // BF cannot be checked before this instruction
    lcd_pulse_enable();            // Send instruction
    __delay_cycles(DELAY_5MS);     // Wait unitl next commnad

    P8OUT = 0x30;                  // BF cannot be checked before this instruction
    lcd_pulse_enable();            // Send instruction
    __delay_cycles(DELAY_100US);   // Wait unitl next commnad

    P8OUT = 0x20;                  // Function set, set 4-bit mode
    lcd_pulse_enable();            // Send instruction

    lcd_send_byte(0x28, FALSE);      // Function set, 4-bit mode, 2 lines
    lcd_send_byte(0x08, FALSE);      // Display off
    lcd_send_byte(0x01, FALSE);      // Clear display
    lcd_send_byte(0x06, FALSE);      // Entry mode set, increment cursor after every character

    lcd_send_byte(0x0c, FALSE);      // Display on
    lcd_send_byte(0x02, FALSE);      // Return home
    lcd_send_byte(0x80, FALSE);      // Force cursor to beginning of first line

}

void lcd_print_text(char* s)
{
    lcd_send_byte(0x80, FALSE);      // Force cursor to beginning of first line
    while((s != 0) && (*s != 0))
    {
        lcd_send_byte(*s, TRUE);
        s++;
    }
}

void lcd_print_password(volatile int* password)
{
    lcd_send_byte(0xC0, FALSE);     // Force cursor to beginning of second line
    unsigned int i = 0;             // Initialize iterator
    for(i = 0; i < 4; ++i)
    {
        lcd_send_byte(password[i] + 48, TRUE);  // Display password on LCD
    }
}

int adc_transform(int ad_result)
{
    int digit = 0; // Resulting digit

    // Corresponding digit intervals of 12-bit ADC result
    if (ad_result < 409) digit = 0;
    else if (ad_result < 819) digit = 1;
    else if (ad_result < 1228) digit = 2;
    else if (ad_result < 1638) digit = 3;
    else if (ad_result < 2047) digit = 4;
    else if (ad_result < 2457) digit = 5;
    else if (ad_result < 2867) digit = 6;
    else if (ad_result < 3276) digit = 7;
    else if (ad_result < 3685) digit = 8;
    else if (ad_result <= 4095) digit = 9;

    return digit;
}
