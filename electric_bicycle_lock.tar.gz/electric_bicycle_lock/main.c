/**
 * @file main.c
 * @brief Electric lock for bicycles
 *
 * In this project electric lock is implemented using ADC results from four
 * potentiometers used as password generator or current combination, depending
 * on witch mode is currently active. Combination is displayed on LCD, and if
 * true password is guessed, pushing the button S1, electric lock mode can
 * be changed to password reset mode.
 *
 * @date 2021
 * @author Mihailo Grbic (gm170047d@student.etf.bg.ac.rs)
 */
#include <msp430.h>
#include <stdint.h>
#include "function.h"

/**
 * @brief Timer period
 *
 * Timer is clocked by ACLK (32768Hz).
 * We want ~32ms period, so use 1023 for CCR0.
 */
#define TIMER_PERIOD        (1023)
/**
 * @brief Current mode
 *
 * Variable indicates if user is password guessing or setting.
 * 0 : guess password
 * 1 : set password
 */
volatile uint8_t mode = 1;
/**
 * @brief Last mode
 *
 * Variable indicates in which mode program was when last checked.
 * 0 : guess password
 * 1 : set password
 */
volatile uint8_t mode_1 = 0;
/**
 * @brief Correct password indicator
 *
 * Variable indicates if guessed password is correct.
 * 0 : incorrect
 * 1 : correct
 */
volatile uint8_t flag = 1;
/**
 * @brief Iterator
 *
 * Variable is used for checking password.
 * 0 : incorrect
 * 1 : correct
 */
volatile uint8_t itr = 0;
/**
 * @brief Password
 *
 * Integer array containing digits of correct password.
 */
volatile int password[] = {
        0x00,
        0x00,
        0x00,
        0x00
};
/*
 * @brief ADC result from first analog input
 *
 * Stores values from ADC12MEM0 register.
 */
volatile int ad1 = 0;
/*
 * @brief ADC result from second analog input
 *
 * Stores values from ADC12MEM1 register.
 */
volatile int ad2 = 0;
/*
 * @brief ADC result from third analog input
 *
 * Stores values from ADC12MEM2 register.
 */
volatile int ad3 = 0;
/*
 * @brief ADC result from fourth analog input
 *
 * Stores values from ADC12MEM3 register.
 */
volatile int ad4 = 0;
/**
 * @brief Current combination
 *
 * Integer array containing ADC result.
 * 4-channel ADC is used with values in range 0-9.
 * Each element of array represent one ADC result.
 */
volatile int ad_result[] = {
        0x00,
        0x00,
        0x00,
        0x00
};

/**
 * @brief Main function
 *
 * Initialization of all peripheral components. ADC result is transformed
 * in valid range and displayed on LCD with current mode.
 */
int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

    // Initialization of LE diodes
    P4DIR |= BIT3;              // Configure P4.3 as out
    P4DIR |= BIT4;              // Configure P4.4 as out

    // Initial state of diodes
    P4OUT |= (flag & BIT0) << 3;
    P4OUT |= (flag & BIT0) << 4;

    // Initialization of button
    P2DIR &= ~BIT4;             // Set P2.4 as in
    P2IES |= BIT4;              // Set P2.4 irq as h->l transition
    P2IFG &= ~BIT4;             // Clear P2.4 IFG
    P2IE |= BIT4;               // Enable P2.4 irq

    // Initialization of LCD display
    lcd_initialize();

    // Initialize timer
    TA0CCR0 = TIMER_PERIOD;             // Set timer period
    TA0CTL = TASSEL__ACLK | MC__UP;     // ACLK source, UP mode
    TA0CCTL0 = CCIE;                    // Enable CCR0 interrupt

    // Initialize ADC
    P7SEL |= BIT6;                      // P7.6 (A14 channel) for ADC
    P7SEL |= BIT7;                      // P7.7 (A15 channel) for ADC
    P5SEL |= BIT0;                      // P5.0 (A8 channel) for ADC
    P5SEL |= BIT1;                      // P5.1 (A9 channel) for ADC

    ADC12CTL0 |= ADC12ON;               // Turn on ADC
    ADC12CTL0 |= ADC12SHT0_8;           // Set sampling timer
    ADC12CTL0 |= ADC12MSC;              // Use multiple channels

    ADC12CTL1 |= ADC12SHP;              // Set SHP in order to use sampling timer for SAMPCON
    ADC12CTL1 |= ADC12CONSEQ_1;         // Conversion mode Sequence-of-channels

    ADC12MCTL0 |= ADC12INCH_14;             // Use channel 14
    ADC12MCTL1 |= ADC12INCH_15;             // Use channel 15
    ADC12MCTL2 |= ADC12INCH_8;              // Use channel 8
    ADC12MCTL3 |= ADC12INCH_9 | ADC12EOS;   // Use channel 9

    ADC12CTL0 |= ADC12ENC;              // Enable conversion

    ADC12IE |= ADC12IE0;                // Enable interrupt for MEM0
    ADC12IE |= ADC12IE1;                // Enable interrupt for MEM1
    ADC12IE |= ADC12IE2;                // Enable interrupt for MEM2
    ADC12IE |= ADC12IE3;                // Enable interrupt for MEM3

    __enable_interrupt();

    while (1)
    {
        // First line of LCD is changing only when mode is changed
        if(mode != mode_1)
        {
            // Display corresponding string
            if (mode == 1)
            {
                lcd_print_text("New Password:   ");
            }
            else
            {
                lcd_print_text("Combination:    ");
            }

            mode_1 = mode;  // Save current state
        }


        // Storing ADC results in array
        ad_result[0] = adc_transform(ad1);
        ad_result[1] = adc_transform(ad2);
        ad_result[2] = adc_transform(ad3);
        ad_result[3] = adc_transform(ad4);

        // Display current combination on LCD display
        lcd_print_password(ad_result);

        // Password reset mode
        if(mode == 1)
        {
            // Save new password
            password[0] = ad_result[0];
            password[1] = ad_result[1];
            password[2] = ad_result[2];
            password[3] = ad_result[3];
        }
        else
        {
            // Check if all digits are same
            itr = 0;
            itr += (password[0]==ad_result[0]) ? (1) : (0);
            itr += (password[1]==ad_result[1]) ? (1) : (0);
            itr += (password[2]==ad_result[2]) ? (1) : (0);
            itr += (password[3]==ad_result[3]) ? (1) : (0);

            if(itr == 4)
            {
                P4OUT |= BIT3;  // Turn on LED
                flag = 1;       // Set flag, password is correct
            }
            else
            {
                P4OUT &= ~BIT3; // Turn off LED
                flag = 0;       // Reset flag, password is incorrect
            }
        }
    }
}
