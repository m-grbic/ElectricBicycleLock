/**
 * @file function.h
 * @brief Declaration of function used to write on LCD display
 *
 * @date 2021
 * @author Mihailo Grbic (gm170047d@student.etf.bg.ac.rs)
 */

#ifndef FUNCTION_H_
#define FUNCTION_H_

/*
 * @brief Symbolic LCD's Register Select pin name
 *
 * Pin is connected to uC pin P8.2
 */
#define     LCM_PIN_RS            BIT2          // P8.2
/*
 * @brief Symbolic LCD's Enable pin name
 *
 * Pin is connected to uC pin P8.3
 */
#define     LCM_PIN_EN            BIT3
/*
 * @brief Symbolic LCD's LSB data pin name
 *
 * Pin is connected to uC pin P8.4
 */
#define     LCM_PIN_D4            BIT4
/*
 * @brief Symbolic LCD's second bit of data pin name
 *
 * Pin is connected to uC pin P8.5
 */
#define     LCM_PIN_D5            BIT5
/*
 * @brief Symbolic LCD's second bit of data pin name
 *
 * Pin is connected to uC pin P8.6
 */
#define     LCM_PIN_D6            BIT6
/*
 * @brief Symbolic LCD's MSB of data pin name
 *
 * Pin is connected to uC pin P8.7
 */
 #define     LCM_PIN_D7            BIT7
/*
 * @brief Symbolic LCD's all pins mask
 */
#define     LCM_PIN_MASK  ((LCM_PIN_RS | LCM_PIN_EN | LCM_PIN_D7 | LCM_PIN_D6 | LCM_PIN_D5 | LCM_PIN_D4))
/*
 * @brief Symbolic LCD's data pins mask
 */
#define     LCM_DATA_MASK (LCM_PIN_D7 | LCM_PIN_D6 | LCM_PIN_D5 | LCM_PIN_D4)
/*
 * @brief Symbolic logical "False" variable used for LCD initialization
 */
#define     FALSE                 0
/*
 * @brief Symbolic logical "True" variable used for LCD initialization
 */
#define     TRUE                  1
/**
 * @brief Delay of 100ms
 *
 * CPU works at 1.048576 MHz.
 * Used as initialization wait time.
 */
#define DELAY_100MS      (10486)
/**
 * @brief Delay of 5ms
 *
 * CPU works at 1.048576 MHz.
 * Used as initialization wait time.
 */
#define DELAY_5MS         (5242)
/**
 * @brief Delay of 20us
 *
 * CPU works at 1.048576 MHz.
 * Enable rise/fall time.
 */
#define DELAY_20US        (21)
/**
 * @brief Delay of 250us
 *
 * CPU works at 1.048576 MHz.
 * Enable pulse width.
 */
#define DELAY_250US       (262)
/**
 * @brief Delay of 100us
 *
 * CPU works at 1.048576 MHz,
 * Used as initialization wait time.
 */
#define DELAY_100US       (105)
/**
 * @brief Delay of 40us
 *
 * CPU works at 1.048576 MHz.
 * Address set-up time.
 */
#define DELAY_40US        (42)
/**
 * @brief Delay of 80us
 *
 * CPU works at 1.048576 MHz.
 * Data set-up time.
 */
#define DELAY_80US        (84)
/**
 * @brief Delay of 10us
 *
 * CPU works at 1.048576 MHz.
 * Address/Data hold time.
 */
#define DELAY_10US        (11)

/*
 * @brief Function for pulsing enable signal
 *
 * Enable signal is set to 1 so LCD can read sent data.
 * Signal is then returned to 0 after some wait time.
 */
extern void lcd_pulse_enable();
/*
 * @brief Function for sending data to LCD
 * @param data - Code or character to be displayed on LCD
 * @param isDat - Indicates code or character
 *
 * Data is sent to LCD in two nibbles in following way:
 * 1: Upper nibble is sent.
 * 2: Enable signal is pulsed.
 * 3: Then, lower nibble is sent.
 * 4: Enable signal is pulsed.
 * Message is code or character, depending on second parameter.
 */
extern void lcd_send_byte(char data, int isData);
/*
 * @brief Function for LCD initialization
 *
 * Port is configured and LCD is initialized as described in following:
 * https://circuitdigest.com/sites/default/files/HD44780U.pdf
 */
extern void lcd_initialize();
/*
 * @brief Function for displaying string on LCD in first row.
 * @param s - String to be displayed on LCD
 *
 * Cursor is forced to begging of first line.
 * Character is sent one by one using implemented function SendChar.
 */
extern void lcd_print_text(char* s);
/*
 * @brief Function for displaying password on LCD in second row
 * @param password - Array of 4 integers, each in range 0-9
 *
 * Cursor is forced to the beginning of second line.
 * Integer is sent one by one using implemented function SendChar.
 */
extern void lcd_print_password(volatile int* password);
/*
 * @brief Function for representing ADC result in 0-9 range
 * @param ad_result - Integer value from MEMx register
 *
 * Range of 12-bit ADC result (0-4095) is rescaled to 0-9 digit.
 */
extern int adc_transform(int ad_result);

#endif /* FUNCTION_H_ */
